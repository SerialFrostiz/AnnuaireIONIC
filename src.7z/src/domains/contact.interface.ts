export interface Contact {
    name: string,
    surname: string,
    address: string,
    company: string,
    phoneNumber: string,
    photo: string,
    mail: string,
    note: string
}